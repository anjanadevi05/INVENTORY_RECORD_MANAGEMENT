package com.records.Inventory.service;

import java.util.Optional;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.records.Inventory.dto.InventoryDto;
import com.records.Inventory.dto.InventoryListDto;
import com.records.Inventory.dto.OrderDto;
import com.records.Inventory.dto.OrderListDto;
import com.records.Inventory.dto.ProductDto;
import com.records.Inventory.dto.ProductListDto;
import com.records.Inventory.dto.SupplierDto;
import com.records.Inventory.dto.SupplierListDto;
import com.records.Inventory.dto.WarehouseDto;
import com.records.Inventory.dto.WarehouseListDto;
import com.records.Inventory.entity.InventoryDetails;
import com.records.Inventory.entity.OrderDetails;
import com.records.Inventory.entity.ProductDetails;
import com.records.Inventory.entity.SupplierDetails;
import com.records.Inventory.entity.WarehouseDetails;
import com.records.Inventory.repository.InventoryRepository;
import com.records.Inventory.repository.OrderRepository;
import com.records.Inventory.repository.ProductRepository;
import com.records.Inventory.repository.SupplierRepository;
import com.records.Inventory.repository.WarehouseRepository;
import com.records.Inventory.util.InventoryUtil;
import com.records.Inventory.exception.InventoryException;
import com.records.Inventory.map.ProductMapper;

@Service
public class InventoryServiceImpl implements InventoryService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private WarehouseRepository warehouseRepository;
    
    @Autowired
    private ProductMapper productMapper;

    @Override
    public Integer saveProductInfo(ProductDto productDto) {
        ProductDetails product = productMapper.mapToProductEntity(productDto);
        productRepository.save(product);
        return product.getId();
    }

    @Override
    public Integer saveInventoryInfo(InventoryDto dto) {
        InventoryDetails inventory = InventoryUtil.dtoToEntity(dto);
        InventoryDetails savedInventory = inventoryRepository.save(inventory);
        return savedInventory.getId();
    }

    @Override
    public Integer saveOrderInfo(OrderDto dto) {
        OrderDetails order = InventoryUtil.dtoToEntity(dto);
        OrderDetails savedOrder = orderRepository.save(order);
        return savedOrder.getId();
    }

    @Override
    public Integer saveSupplierInfo(SupplierDto dto) {
        SupplierDetails supplier = InventoryUtil.dtoToEntity(dto);
        SupplierDetails savedSupplier = supplierRepository.save(supplier);
        return savedSupplier.getId();
    }

    @Override
    public Integer saveWarehouseInfo(WarehouseDto dto) {
        WarehouseDetails warehouse = InventoryUtil.dtoToEntity(dto);
        WarehouseDetails savedWarehouse = warehouseRepository.save(warehouse);
        return savedWarehouse.getId();
    }

    @Override
    public ProductDto getProductInfo(Integer productId) {
        Optional<ProductDetails> productOptional = productRepository.findById(productId);

        if (productOptional.isPresent()) {
            ProductDetails product = productOptional.get();
            return InventoryUtil.entityToDto(product);
        } else {
            throw new InventoryException("Product not found with ID: " + productId);
        }
    }

	@Override
	public InventoryDto getInventoryInfo(Integer id) {
		Optional<InventoryDetails> inventOptional = inventoryRepository.findByInventId(id);

        if (inventOptional.isPresent()) {
            InventoryDetails inventory = inventOptional.get();
            return InventoryUtil.entityToDto(inventory);
        } else {
            throw new InventoryException("Inventory not found with ID: " + id);
        }
	}

	@Override
	public WarehouseDto getWarehouseInfo(Integer id) {
		Optional<WarehouseDetails> WarehouseOptional = warehouseRepository.findByHouseId(id);

        if (WarehouseOptional.isPresent()) {
            WarehouseDetails warehouse= WarehouseOptional.get();
            return InventoryUtil.entityToDto(warehouse);
        } else {
            throw new InventoryException("Warehouse not found with ID: " + id);
        }
	}

	@Override
	public SupplierDto getSupplierInfo(Integer id) {
		
		Optional<SupplierDetails> SupplierOptional = supplierRepository.findBySupplierId(id);

        if (SupplierOptional.isPresent()) {
        	SupplierDetails supplier= SupplierOptional.get();
            return InventoryUtil.entityToDto(supplier);
        } else {
            throw new InventoryException("Supplier not found with ID: " + id);
        }
	}

	@Override
	public OrderDto getOrderInfo(Integer id) {
		Optional<OrderDetails> OrderOptional = orderRepository.findByOrderId(id);

        if (OrderOptional.isPresent()) {
        	OrderDetails order= OrderOptional.get();
            return InventoryUtil.entityToDto(order);
        } else {
            throw new InventoryException("Order not found with ID: " + id);
        }
	}

	/*@Override
    public InventoryListDto getAllInventoryInfo() {
        return InventoryListDto.builder()
                .inventories(inventoryRepository.findAll())
                .build();
    }

    @Override
    public ProductListDto getAllProductInfo() {
        return ProductListDto.builder()
                .productList(productRepository.findAll())
                .build();
    }

    @Override
    public WarehouseListDto getAllWarehouseInfo() {
        return WarehouseListDto.builder()
                .warehouseList(warehouseRepository.findAll())
                .build();
    }

    @Override
    public SupplierListDto getAllSupplierInfo() {
        return SupplierListDto.builder()
                .suppliers(supplierRepository.findAll())
                .build();
    }

    @Override
    public OrderListDto getAllOrderInfo() {
        return OrderListDto.builder()
                .orderList(orderRepository.findAll())
                .build();
    }*/

    @Override
    public Integer updateInventoryInfo(InventoryDto dto) {
        return inventoryRepository.save(dto).getId();
    }

    @Override
    public Integer updateProductInfo(ProductDto dto) {
        return productRepository.save(dto).getId();
    }

    @Override
    public Integer updateWarehouseInfo(WarehouseDto dto) {
        return warehouseRepository.save(dto).getId();
    }

    @Override
    public Integer updateSupplierInfo(SupplierDto dto) {
        return supplierRepository.save(dto).getId();
    }

    @Override
    public Integer updateOrderInfo(OrderDto dto) {
        return orderRepository.save(dto).getId();
    }
}
