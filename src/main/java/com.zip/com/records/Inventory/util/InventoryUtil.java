package com.records.Inventory.util;

import java.util.List;
import java.util.stream.Collectors;

import com.records.Inventory.dto.InventoryDto;
import com.records.Inventory.dto.OrderDto;
import com.records.Inventory.dto.OrderListDto;
import com.records.Inventory.dto.ProductDto;
import com.records.Inventory.dto.SupplierDto;
import com.records.Inventory.dto.SupplierListDto;
import com.records.Inventory.dto.WarehouseDto;
import com.records.Inventory.entity.InventoryDetails;
import com.records.Inventory.entity.OrderDetails;
import com.records.Inventory.entity.ProductDetails;
import com.records.Inventory.entity.SupplierDetails;
import com.records.Inventory.entity.WarehouseDetails;

public class InventoryUtil {

    private InventoryUtil() {
    }

    // Convert ProductDto to ProductDetails
    public static ProductDetails dtoToEntity(ProductDto dto) {
        return ProductDetails.builder()
                .id(dto.getProdId())
                .prodName(dto.getProdName())
                .prodCategory(dto.getProdCategory())
                .prodPrice(dto.getProdPrice())
                .build();
    }

    // Convert InventoryDto to InventoryDetails
    public static InventoryDetails dtoToEntity(InventoryDto dto) {
        return InventoryDetails.builder()
                .Id(dto.getId())
                .quantity(dto.getQuantity())
                .warehouse(dtoToEntity(dto.getWarehouse())) // Convert WarehouseDto to WarehouseDetails
                .product(dtoToEntity(dto.getProduct())) // Convert ProductDto to ProductDetails
                .build();
    }

    // Convert WarehouseDto to WarehouseDetails
    public static WarehouseDetails dtoToEntity(WarehouseDto dto) {
        return WarehouseDetails.builder()
                .id(dto.getId())
                .name(dto.getName())
                .location(dto.getLocation())
                .contact(dto.getContact())
                .build();
    }

    // Convert List of SupplierDto to List of SupplierDetails
    public static List<SupplierDetails> dtoToEntities(SupplierListDto dto) {
        return dto.getSuppliers().stream().map(supplier -> dtoToEntity(supplier)).collect(Collectors.toList());
    }

    // Convert List of OrderDto to List of OrderDetails
    public static List<OrderDetails> dtoToEntities(OrderListDto dto) {
        return dto.getOrders().stream().map(order -> dtoToEntity(order)).collect(Collectors.toList());
    }

    // Convert SupplierDto to SupplierDetails
    public static SupplierDetails dtoToEntity(SupplierDto dto) {
        return SupplierDetails.builder()
                .id(dto.getId()) // Ensure SupplierDto has an ID field
                .name(dto.getName())
                .location(dto.getLocation())
                .contactInformation(dto.getContactInformation())
                .build();
    }

    // Convert OrderDto to OrderDetails
    public static OrderDetails dtoToEntity(OrderDto dto) {
        return OrderDetails.builder()
                .id(dto.getId())
                .orderDate(dto.getOrderDate())
                .quantity(dto.getQuantity())
                .totalPrice(dto.getTotalPrice())
                .product(dtoToEntity(dto.getProduct())) // Convert ProductDto to ProductDetails
                .supplier(dtoToEntity(dto.getSupplier())) // Convert SupplierDto to SupplierDetails
                .build();
    }

 // Convert ProductDetails to ProductDto
    public static ProductDto entityToDto(ProductDetails entity) {
        return ProductDto.builder()
                .prodId(entity.getId()) // Map prodId from entity
                .prodName(entity.getProdName())
                .prodCategory(entity.getProdCategory())
                .prodPrice(entity.getProdPrice())
                .build();
    }


    // Convert InventoryDetails to InventoryDto
    public static InventoryDto entityToDto(InventoryDetails entity) {
        return InventoryDto.builder()
                .id(entity.getId())
                .quantity(entity.getQuantity())
                .warehouse(entityToDto(entity.getWarehouse())) // Convert WarehouseDetails to WarehouseDto
                .product(entityToDto(entity.getProduct())) // Convert ProductDetails to ProductDto
                .build();
    }

    // Convert WarehouseDetails to WarehouseDto
    public static WarehouseDto entityToDto(WarehouseDetails entity) {
        return WarehouseDto.builder()
                .id(entity.getId())
                .name(entity.getName())
                .location(entity.getLocation())
                .contact(entity.getContact())
                .build();
    }

    // Convert SupplierDetails to SupplierDto
    public static SupplierDto entityToDto(SupplierDetails entity) {
        return SupplierDto.builder()
                .id(entity.getId())
                .name(entity.getName())
                .location(entity.getLocation())
                .contactInformation(entity.getContactInformation())
                .build();
    }

    // Convert OrderDetails to OrderDto
    public static OrderDto entityToDto(OrderDetails entity) {
        return OrderDto.builder()
                .id(entity.getId())
                .orderDate(entity.getOrderDate())
                .quantity(entity.getQuantity())
                .totalPrice(entity.getTotalPrice())
                .product(entityToDto(entity.getProduct())) // Convert ProductDetails to ProductDto
                .supplier(entityToDto(entity.getSupplier())) // Convert SupplierDetails to SupplierDto
                .build();
    }
}
