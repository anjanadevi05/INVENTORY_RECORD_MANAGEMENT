package com.records.Inventory.map;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.records.Inventory.dto.InventoryDto;
import com.records.Inventory.dto.ProductDto;
import com.records.Inventory.dto.SupplierDto;
import com.records.Inventory.dto.WarehouseDto;
import com.records.Inventory.entity.InventoryDetails;
import com.records.Inventory.entity.OrderDetails;
import com.records.Inventory.entity.ProductDetails;
import com.records.Inventory.entity.SupplierDetails;
import com.records.Inventory.entity.WarehouseDetails;

@Component
public class ProductMapper {
	
	public ProductDetails mapToProductEntity(ProductDto productDto) {
        ProductDetails product = new ProductDetails();
        product.setId(productDto.getProdId());
        product.setProdName(productDto.getProdName());
        product.setProdCategory(productDto.getProdCategory());
        product.setProdPrice(productDto.getProdPrice());

        List<InventoryDetails> inventories = productDto.getInventories().stream()
                .map(inventoryDto -> {
                    InventoryDetails inventory = new InventoryDetails();
                    inventory.setQuantity(inventoryDto.getQuantity());
                    inventory.setWarehouse(mapToWarehouseEntity(inventoryDto.getWarehouse()));
                    inventory.setProduct(product);  // Set the reference back to product
                    return inventory;
                }).collect(Collectors.toList());

        List<OrderDetails> orders = productDto.getOrders().stream()
                .map(orderDto -> {
                    OrderDetails order = new OrderDetails();
                    order.setQuantity(orderDto.getQuantity());
                    order.setOrderDate(orderDto.getOrderDate());
                    order.setProduct(product);  // Set the reference back to product
                    return order;
                }).collect(Collectors.toList());

        product.setInventories(inventories);
        product.setOrders(orders);
        product.setSuppliers(productDto.getSuppliers().stream()
                .map(this::mapToSupplierEntity)
                .collect(Collectors.toList()));

        return product;
    }

    private SupplierDetails mapToSupplierEntity(SupplierDto supplierDto) {
        SupplierDetails supplier = new SupplierDetails();
        supplier.setId(supplierDto.getId());
        supplier.setName(supplierDto.getName());
        supplier.setContactInformation(supplierDto.getContactInformation());
        return supplier;
    }

    private WarehouseDetails mapToWarehouseEntity(WarehouseDto warehouseDto) {
        WarehouseDetails warehouse = new WarehouseDetails();
        warehouse.setId(warehouseDto.getId());
        warehouse.setHouseId(warehouseDto.getHouseId());
        warehouse.setName(warehouseDto.getName());
        warehouse.setLocation(warehouseDto.getLocation());
        warehouse.setContact(warehouseDto.getContact());
        return warehouse;
    }

}
