package com.records.Inventory.controller;

import static com.records.Inventory.constant.InventoryConstant.INVENTORY_INFO_SAVED_MESSAGE;
import static com.records.Inventory.constant.InventoryConstant.PRODUCT_INFO_SAVED_MESSAGE;
import static com.records.Inventory.constant.InventoryConstant.WAREHOUSE_INFO_SAVED_MESSAGE;
import static com.records.Inventory.constant.InventoryConstant.SUPPLIER_INFO_SAVED_MESSAGE;
import static com.records.Inventory.constant.InventoryConstant.ORDER_INFO_SAVED_MESSAGE;
import static com.records.Inventory.constant.InventoryConstant.INVENTORY_INFO_FETCH_MESSAGE;
import static com.records.Inventory.constant.InventoryConstant.PRODUCT_INFO_FETCH_MESSAGE;
import static com.records.Inventory.constant.InventoryConstant.WAREHOUSE_INFO_FETCH_MESSAGE;
import static com.records.Inventory.constant.InventoryConstant.SUPPLIER_INFO_FETCH_MESSAGE;
import static com.records.Inventory.constant.InventoryConstant.ORDER_INFO_FETCH_MESSAGE;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.records.Inventory.dto.InventoryDto;
import com.records.Inventory.dto.InventoryListDto;
import com.records.Inventory.dto.OrderDto;
import com.records.Inventory.dto.OrderListDto;
import com.records.Inventory.dto.ProductDto;
import com.records.Inventory.dto.ProductListDto;
import com.records.Inventory.dto.SupplierDto;
import com.records.Inventory.dto.SupplierListDto;
import com.records.Inventory.dto.WarehouseDto;
import com.records.Inventory.dto.WarehouseListDto;
import com.records.Inventory.entity.ProductDetails;
import com.records.Inventory.map.ProductMapper;
import com.records.Inventory.repository.ProductRepository;
import com.records.Inventory.response.CommanResponse;
import com.records.Inventory.service.InventoryService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("api/v1/inventory")
@RequiredArgsConstructor
@Slf4j
public class InventoryController {

    private final InventoryService inventoryService;
    
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductMapper productMapper;

  
   /* @GetMapping("/AllInventory")
    public ResponseEntity<CommanResponse<InventoryListDto>> getAllInventoryInfo() {
        log.info("InventoryServiceImpl :: getAllInventoryInfo");
        InventoryListDto inventoryList = inventoryService.getAllInventoryInfo();
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<InventoryListDto>builder()
                .isError(false)
                .data(inventoryList)
                .message(INVENTORY_INFO_FETCH_MESSAGE)
                .build());
    }

    @GetMapping("/AllProduct")
    public ResponseEntity<CommanResponse<ProductListDto>> getAllProductInfo() {
        log.info("InventoryServiceImpl :: getAllProductInfo");
        ProductListDto productList = inventoryService.getAllProductInfo();
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<ProductListDto>builder()
                .isError(false)
                .data(productList)
                .message(PRODUCT_INFO_FETCH_MESSAGE)
                .build());
    }

    @GetMapping("/AllWarehouse")
    public ResponseEntity<CommanResponse<WarehouseListDto>> getAllWarehouseInfo() {
        log.info("InventoryServiceImpl :: getAllWarehouseInfo");
        WarehouseListDto warehouseList = inventoryService.getAllWarehouseInfo();
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<WarehouseListDto>builder()
                .isError(false)
                .data(warehouseList)
                .message(WAREHOUSE_INFO_FETCH_MESSAGE)
                .build());
    }

    @GetMapping("/AllSupplier")
    public ResponseEntity<CommanResponse<SupplierListDto>> getAllSupplierInfo() {
        log.info("InventoryServiceImpl :: getAllSupplierInfo");
        SupplierListDto supplierList = inventoryService.getAllSupplierInfo();
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<SupplierListDto>builder()
                .isError(false)
                .data(supplierList)
                .message(SUPPLIER_INFO_FETCH_MESSAGE)
                .build());
    }

    @GetMapping("/AllOrder")
    public ResponseEntity<CommanResponse<OrderListDto>> getAllOrderInfo() {
        log.info("InventoryServiceImpl :: getAllOrderInfo");
        OrderListDto orderList = inventoryService.getAllOrderInfo();
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<OrderListDto>builder()
                .isError(false)
                .data(orderList)
                .message(ORDER_INFO_FETCH_MESSAGE)
                .build());
    }*/
    
    @GetMapping("/product")
    public ProductDto getProductInfo() {
        return ProductDto.builder().build();
    }

    @GetMapping("/order")
    public OrderDto getOrderInfo() {
        return OrderDto.builder().build();
    }

    @GetMapping("/inventory")
    public InventoryDto getInventoryInfo() {
        return InventoryDto.builder().build();
    }

    @GetMapping("/warehouse")
    public WarehouseDto getWarehouseInfo() {
        return WarehouseDto.builder().build();
    }

    @GetMapping("/supplier")
    public SupplierDto getSupplierInfo() {
        return SupplierDto.builder().build();
    }

    @GetMapping("/inventory/{id}")
    public ResponseEntity<CommanResponse<InventoryDto>> getInventoryInfo(@PathVariable Integer id) {
        log.info("InventoryServiceImpl :: getInventoryInfo");
        InventoryDto inventoryInfo = inventoryService.getInventoryInfo(id);
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<InventoryDto>builder()
                .isError(false)
                .data(inventoryInfo)
                .message(INVENTORY_INFO_FETCH_MESSAGE)
                .build());
    }

    @GetMapping("/product/{id}")
    public ResponseEntity<CommanResponse<ProductDto>> getProductInfo(@PathVariable Integer id) {
        ProductDto productInfo = inventoryService.getProductInfo(id);
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<ProductDto>builder()
                .isError(false)
                .data(productInfo)
                .message(PRODUCT_INFO_FETCH_MESSAGE)
                .build());
    }

    @GetMapping("/warehouse/{id}")
    public ResponseEntity<CommanResponse<WarehouseDto>> getWarehouseInfo(@PathVariable Integer id) {
        log.info("InventoryServiceImpl :: getWarehouseInfo");
        WarehouseDto warehouseInfo = inventoryService.getWarehouseInfo(id);
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<WarehouseDto>builder()
                .isError(false)
                .data(warehouseInfo)
                .message(WAREHOUSE_INFO_FETCH_MESSAGE)
                .build());
    }

    @GetMapping("/supplier/{id}")
    public ResponseEntity<CommanResponse<SupplierDto>> getSupplierInfo(@PathVariable Integer id) {
        log.info("InventoryServiceImpl :: getSupplierInfo");
        SupplierDto supplierInfo = inventoryService.getSupplierInfo(id);
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<SupplierDto>builder()
                .isError(false)
                .data(supplierInfo)
                .message(SUPPLIER_INFO_FETCH_MESSAGE)
                .build());
    }

    @GetMapping("/order/{id}")
    public ResponseEntity<CommanResponse<OrderDto>> getOrderInfo(@PathVariable Integer id) {
        log.info("InventoryServiceImpl :: getOrderInfo");
        OrderDto orderInfo = inventoryService.getOrderInfo(id);
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<OrderDto>builder()
                .isError(false)
                .data(orderInfo)
                .message(ORDER_INFO_FETCH_MESSAGE)
                .build());
    }

    @PostMapping("/inventory")
    public ResponseEntity<CommanResponse<Integer>> saveInventoryInfo(@RequestBody InventoryDto dto) {
        if (dto == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(CommanResponse.<Integer>builder()
                    .isError(true)
                    .data(null)
                    .message("Invalid request body")
                    .build());
        }
        
        log.info("InventoryServiceImpl :: saveInventoryInfo");
        InventoryDto basicInventoryDto = InventoryDto.builder()
            .inventId(dto.getInventId())
            .quantity(dto.getQuantity())
            .build();
        
        Integer id = inventoryService.saveInventoryInfo(basicInventoryDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(CommanResponse.<Integer>builder()
                .isError(false)
                .data(id)
                .message(INVENTORY_INFO_SAVED_MESSAGE)
                .build());
    }


    @PostMapping("/product")
    public ResponseEntity<CommanResponse<Integer>> saveProductInfo(@RequestBody ProductDto dto) {
        // Only saving basic details for Product
        log.info("InventoryServiceImpl :: saveProductInfo");
        ProductDto basicProductDto = ProductDto.builder()
            .prodId(dto.getProdId())
            .prodName(dto.getProdName())
            .prodCategory(dto.getProdCategory())
            .prodPrice(dto.getProdPrice())
            .build();
        
        Integer id = inventoryService.saveProductInfo(basicProductDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(CommanResponse.<Integer>builder()
                .isError(false)
                .data(id)
                .message(PRODUCT_INFO_SAVED_MESSAGE)
                .build());
    }

    @PostMapping("/warehouse")
    public ResponseEntity<CommanResponse<Integer>> saveWarehouseInfo(@RequestBody WarehouseDto dto) {
        // Only saving basic details for Warehouse
        log.info("InventoryServiceImpl :: saveWarehouseInfo");
        WarehouseDto basicWarehouseDto = WarehouseDto.builder()
            .houseId(dto.getHouseId())
            .name(dto.getName())
            .location(dto.getLocation())
            .build();
        
        Integer id = inventoryService.saveWarehouseInfo(basicWarehouseDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(CommanResponse.<Integer>builder()
                .isError(false)
                .data(id)
                .message(WAREHOUSE_INFO_SAVED_MESSAGE)
                .build());
    }

    @PostMapping("/supplier")
    public ResponseEntity<CommanResponse<Integer>> saveSupplierInfo(@RequestBody SupplierDto dto) {
        // Only saving basic details for Supplier
        log.info("InventoryServiceImpl :: saveSupplierInfo");
        SupplierDto basicSupplierDto = SupplierDto.builder()
            .id(dto.getId())
            .name(dto.getName())
            .location(dto.getLocation())
            .contactInformation(dto.getContactInformation())
            .build();
        
        Integer id = inventoryService.saveSupplierInfo(basicSupplierDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(CommanResponse.<Integer>builder()
                .isError(false)
                .data(id)
                .message(SUPPLIER_INFO_SAVED_MESSAGE)
                .build());
    }

    @PostMapping("/order")
    public ResponseEntity<CommanResponse<Integer>> saveOrderInfo(@RequestBody OrderDto dto) {
        // Only saving basic details for Order
        log.info("InventoryServiceImpl :: saveOrderInfo");
        OrderDto basicOrderDto = OrderDto.builder()
            .orderId(dto.getOrderId())
            .orderDate(dto.getOrderDate())
            .totalPrice(dto.getTotalPrice())
            .quantity(dto.getQuantity())
            .build();
        
        Integer id = inventoryService.saveOrderInfo(basicOrderDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(CommanResponse.<Integer>builder()
                .isError(false)
                .data(id)
                .message(ORDER_INFO_SAVED_MESSAGE)
                .build());
    }

    @PutMapping("/inventory")
    public ResponseEntity<CommanResponse<Integer>> updateInventoryInfo(@RequestBody InventoryDto dto) {
        log.info("InventoryServiceImpl :: updateInventoryInfo");
        Integer id = inventoryService.updateInventoryInfo(dto);
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<Integer>builder()
                .isError(false)
                .data(id)
                .message(INVENTORY_INFO_SAVED_MESSAGE)
                .build());
    }

    @PutMapping("/product")
    public ResponseEntity<CommanResponse<Integer>> updateProductInfo(@RequestBody ProductDto dto) {
        log.info("InventoryServiceImpl :: updateProductInfo");
        Integer id = inventoryService.updateProductInfo(dto);
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<Integer>builder()
                .isError(false)
                .data(id)
                .message(PRODUCT_INFO_SAVED_MESSAGE)
                .build());
    }

    @PutMapping("/warehouse")
    public ResponseEntity<CommanResponse<Integer>> updateWarehouseInfo(@RequestBody WarehouseDto dto) {
        log.info("InventoryServiceImpl :: updateWarehouseInfo");
        Integer id = inventoryService.updateWarehouseInfo(dto);
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<Integer>builder()
                .isError(false)
                .data(id)
                .message(WAREHOUSE_INFO_SAVED_MESSAGE)
                .build());
    }

    @PutMapping("/supplier")
    public ResponseEntity<CommanResponse<Integer>> updateSupplierInfo(@RequestBody SupplierDto dto) {
        log.info("InventoryServiceImpl :: updateSupplierInfo");
        Integer id = inventoryService.updateSupplierInfo(dto);
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<Integer>builder()
                .isError(false)
                .data(id)
                .message(SUPPLIER_INFO_SAVED_MESSAGE)
                .build());
    }

    @PutMapping("/order")
    public ResponseEntity<CommanResponse<Integer>> updateOrderInfo(@RequestBody OrderDto dto) {
        log.info("InventoryServiceImpl :: updateOrderInfo");
        Integer id = inventoryService.updateOrderInfo(dto);
        return ResponseEntity.status(HttpStatus.OK).body(CommanResponse.<Integer>builder()
                .isError(false)
                .data(id)
                .message(ORDER_INFO_SAVED_MESSAGE)
                .build());
    }

}
